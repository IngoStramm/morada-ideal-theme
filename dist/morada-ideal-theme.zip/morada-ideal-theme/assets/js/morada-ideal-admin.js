(() => {
    'use strict';
    console.log('morada-ideal-admin.js');
})();