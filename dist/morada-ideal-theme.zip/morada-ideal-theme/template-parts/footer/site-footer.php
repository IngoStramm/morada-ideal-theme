            <!-- footer -->
            <footer class="footer">
                <?php echo get_template_part('template-parts/footer/top', 'footer'); ?>
                <?php echo get_template_part('template-parts/footer/inner', 'footer'); ?>
                <?php echo get_template_part('template-parts/footer/bottom', 'footer'); ?>
            </footer>
            <!-- end footer -->