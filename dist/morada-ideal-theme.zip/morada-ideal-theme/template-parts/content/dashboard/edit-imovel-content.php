<?php get_sidebar('dashboard');
?>

<div class="main-content">
    <?php echo mi_edit_imovel_progress_bar(); ?>
    <div class="main-content-inner">
        <?php get_template_part('template-parts/content/dashboard/dashboard-inner', 'top'); ?>
        <div class="wrapper-content row">
            <div class="col-lg-7 col-xl-8">
                <div class="widget-box-2">
                    <h3 class="title fw-bold"><?php _e('Cadastrar Imóvel', 'mi'); ?></h3>
                    <?php get_template_part('template-parts/content/dashboard/imovel', 'form'); ?>
                </div>
            </div>
            <div class="col-lg-5 col-xl-4">
                <div class="widget-box-2 widget-box-info mess-box">
                    <h4 class="title"><?php _e('Informação que vale a pena saber', 'mi'); ?>:</h4>
                    <div class="content">
                        <p><?php _e('Separe as fotos do imóvel. Se ainda não tiver, pode adicionar depois, mas sem fotos o anúncio perde muita visibilidade.', 'mi'); ?></p>
                        <p><?php _e('Os dois primeiros anúncios são por nossa conta, assim você pode testar como funciona. Vale para apartamentos, casas, terrenos, espaços comerciais, seja para venda ou arrendamento.', 'mi'); ?></p>
                        <p><?php _e('Além disso, dá para anunciar até 5 quartos gratuitamente, caso sejam para compartilhamento. Esses não entram no limite de anúncios grátis.', 'mi'); ?></p>
                        <p><?php _e('Para manter a qualidade da plataforma, cobramos uma taxa em algumas situações:', 'mi'); ?></p>
                        <ul class="default-list">
                            <li><?php _e('Quando há mais de dois imóveis anunciados.', 'mi'); ?></li>
                            <li><?php _e('Para anúncios duplicados.', 'mi'); ?></li>
                            <li><?php _e('Para imóveis à venda acima de 1 milhão de euros.', 'mi'); ?></li>
                            <li><?php _e('Para arrendamentos acima de 2.500 euros/mês.', 'mi'); ?></li>
                        </ul>
                        <div class="card-box">
                            <div class="card-icon"><?php echo mi_get_icon('thunder'); ?></div>
                            <div class="card-content">
                                <h6><?php _e('Quer vender o seu imóvel mais rápido?', 'mi'); ?></h6>
                                <p><?php _e('Encontre a agência imobiliária ideal para o seu caso.', 'mi'); ?></p>
                            </div>
                        </div>
                        <div class="card-box">
                            <div class="card-icon"><?php echo mi_get_icon('working-man'); ?></div>
                            <div class="card-content">
                                <h6><?php _e('Trabalha no mercado imobiliário?', 'mi'); ?></h6>
                                <p><?php _e('Veja as vantagens que oferecemos para profissionais.', 'mi'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo mi_dashboard_footer(); ?>
</div>

<div class="overlay-dashboard"></div>