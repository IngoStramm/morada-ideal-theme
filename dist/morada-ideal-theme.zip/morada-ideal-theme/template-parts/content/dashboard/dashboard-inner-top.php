<?php echo mi_button_toggle_dashboard_sidebar(); ?>
<?php do_action('dashboard_announces'); ?>
