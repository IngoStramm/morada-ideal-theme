<section class="flat-section flat-contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h4><?php the_title(); ?></h4>
                <div class="body-2 text-variant-1"><?php the_content(); ?></div>
            </div>
        </div>
    </div>
</section>