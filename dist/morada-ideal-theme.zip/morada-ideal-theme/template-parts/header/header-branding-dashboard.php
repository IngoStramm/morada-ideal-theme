<div class="logo-box flex">
    <div class="logo">
        <a href="<?php echo get_home_url() ?>">
            <?php echo mi_logo(); ?>
        </a>
    </div>
    <div class="button-show-hide">
        <span class="icon icon-categories"></span>
    </div>
</div>