<?php

/**
 * mi_total_imoveis_sort_message
 *
 * @return string
 */
function mi_total_imoveis_sort_message()
{
    global $wp_query;
    if (!is_main_query() || is_admin() || $wp_query->get('post_type') === 'nav_menu_item') {
        return;
    }
    $post_count = $wp_query->found_posts;
    $search_term = isset($wp_query->query_vars['search']) && $wp_query->query_vars['search'] ? $wp_query->query_vars['search'] : null;
    $output = '';
    $output .= $search_term ? sprintf(__('%s imóveis encontrados em %s', 'mi'), $post_count, $search_term) : sprintf(__('%s imóveis encontrados', 'mi'), $post_count);
    return $output;
}

/**
 * mi_imovel_meta_list
 *
 * @param  string $imovel_tipologia
 * @param  string $imovel_casas_banho
 * @param  string $imovel_area_bruta
 * @return string
 */
function mi_imovel_meta_list($imovel_tipologia = null, $imovel_casas_banho = null, $imovel_area_bruta = null)
{
    $output = '';
    $output .= '
    <ul class="meta-list">';

    if ($imovel_tipologia) {
        $output .= '
        <li class="item">
                <i class="icon icon-bed"></i>
                <span class="text-variant-1">' . __('Quartos', 'mi') . ':</span>
                <span class="fw-6">' . $imovel_tipologia . '</span>
            </li>';
    }

    if ($imovel_casas_banho) {
        $output .= '
            <li class="item">
                <i class="icon icon-bath"></i>
                <span class="text-variant-1">' . __('Casa de banho', 'mi') . ':</span>
                <span class="fw-6">' . $imovel_casas_banho . '</span>
            </li>';
    }

    if ($imovel_area_bruta) {
        $output .= '
            <li class="item">
                <i class="icon icon-sqft"></i>
                <span class="text-variant-1">' . __('Área', 'mi') . ':</span>
                <span class="fw-6">' . $imovel_area_bruta . 'm²</span>
            </li>';
    }
    $output .= '
    </ul>';
    return $output;
}

/**
 * mi_autocomplete_search_input
 *
 * @param  string $imovel_lat
 * @param  string $imovel_lng
 * @return string
 */
function mi_autocomplete_search_input($imovel_lat = '', $imovel_lng = '')
{
    $search = isset($_GET['search']) && $_GET['search'] ? $_GET['search'] : null;
    if (!$imovel_lat) {
        $imovel_lat = isset($_GET['lat']) && $_GET['lat'] ? $_GET['lat'] : null;
    }
    if (!$imovel_lng) {
        $imovel_lng = isset($_GET['lng']) && $_GET['lng'] ? $_GET['lng'] : null;
    }
    $imovel_estado = isset($_GET['imovel_estado']) && $_GET['imovel_estado'] ? $_GET['imovel_estado'] : null;
    $imovel_cidade = isset($_GET['imovel_cidade']) && $_GET['imovel_cidade'] ? $_GET['imovel_cidade'] : null;
    $imovel_codigo_postal = isset($_GET['imovel_codigo_postal']) && $_GET['imovel_codigo_postal'] ? $_GET['imovel_codigo_postal'] : null;
    $imovel_rua = isset($_GET['imovel_rua']) && $_GET['imovel_rua'] ? $_GET['imovel_rua'] : null;
    $output = '';
    $output .= '
    <div class="autocomplete-wrapper form-style">
        <div class="group-ip ip-icon">
            <input type="search" class="form-control autocomplete search-address-group" placeholder="' . __('Localização', 'mi') . '" value="' . $search . '" name="search" id="autocomplete" title="' . __('Pesquisar por', 'mi') . '">
            <a href="#" class="icon-right icon-location"></a>
        </div>
        <div id="autocomplete-message" class="autocomplete-message invalid-feedback px-2">' . __('Digite um endereço válido para fazer a pesquisa.', 'mi') . '</div>
        <input type="hidden" value="' . $imovel_lat . '" name="lat" />
        <input type="hidden" value="' . $imovel_lng . '" name="lng" />
        <input type="hidden" value="' . $imovel_estado . '" name="imovel_estado" />
        <input type="hidden" value="' . $imovel_cidade . '" name="imovel_cidade" />
        <input type="hidden" value="' . $imovel_codigo_postal . '" name="imovel_codigo_postal" />
        <input type="hidden" value="' . $imovel_rua . '" name="imovel_rua" />
    </div>
    ';
    return $output;
}

/**
 * mi_range_widget
 *
 * @param  string $text
 * @param  string $min_price
 * @param  string $max_price
 * @param  string $min_name
 * @param  string $max_name
 * @return string
 */
function mi_range_widget($id, $text, $min_price, $max_price, $min_name, $max_name)
{
    $output = '';
    $output .= '
    <div class="form-style widget-range">
        <div class="box-title-range">
            <span class="title-range fw-6">' . $text . ':</span>
            <div class="caption-range">
                <span data-min-caption class="fw-6"></span>
                <span class="fw-6">-</span>
                <span data-max-caption class="fw-6"></span>
            </div>
        </div>
        <div id="' . $id . '"></div>
        <div class="slider-labels">
            <input type="hidden" data-min-value name="' . $min_name . '" value="' . $min_price . '">
            <input type="hidden" data-max-value name="' . $max_name . '" value="' . $max_price . '">
        </div>
    </div>
    ';
    return $output;
}

/**
 * mi_radio_list
 *
 * @param  string $text
 * @param  array $terms
 * @param  mixed $selected_tipo_term_id
 * @param  string $slug
 * @return string
 */
function mi_radio_list($text, $terms, $selected_tipo_term_id, $slug, $radio = true, $term_array = false)
{
    $input_name = $term_array ? $slug . '-terms[]' : $slug . '-term';
    $type = $radio ? 'radio' : 'checkbox';
    $output = '';
    $output .= '
    <div class="box">
        <div class="form-style wd-amenities">
            <div class="group-checkbox">
                <h6 class="title text-black-2">' . $text . ':</h6>
                <div class="group-amenities">';
    foreach ($terms as $term) {
        if (is_array($selected_tipo_term_id)) {
            $checked = $selected_tipo_term_id && in_array((string)$term->term_id, $selected_tipo_term_id) ? 'checked' : '';
        } else {
            $checked = $term->term_id === (int)$selected_tipo_term_id ? 'checked' : '';
        }
        $output .= '
                    <fieldset class="amenities-item">
                        <input type="' . $type . '" class="tf-checkbox style-1" value="' . $term->term_id . '" id="' . $slug . '-term-' . $term->term_id . '" name="' . $input_name . '" ' . $checked . '>
                        <label for="' . $slug . '-term-' . $term->term_id . '" class="text-cb-amenities">' . $term->name . '</label>
                    </fieldset>';
    }
    $output .= '
                </div>
            </div>
        </div>
    </div>
    ';
    return $output;
}

/**
 * mi_overview_list_item_term
 *
 * @param  array $terms
 * @param  string $icon
 * @param  string $text
 * @return string
 */
function mi_overview_list_item_term($terms, $icon, $text)
{
    $output = '';
    if ($terms) {
        $output .= '
        <li class="item">
            <a href="#" class="box-icon w-52"><i class="icon ' .  $icon . '"></i></a>
            <div class="content">
                <span class="label">' . $text . '</span>';
        $count = 0;
        $first = 0;
        $last = count($terms) - 1;
        foreach ($terms as $term) {
            if (!$term->parent) {
                $sep = '';
                if ($count !== $first && $count !== $last) {
                    $sep .= ', ';
                }
                $output .= '
                <span>' . $sep . $term->name . '</span>';
                $count++;
            }
        }
        $output .= '
            </div>
        </li>';
    }
    return $output;
}

/**
 * mi_overview_list_item_text
 *
 * @param  string $item
 * @param  string $icon
 * @param  string $text
 * @return string
 */
function mi_overview_list_item_text($item, $icon, $text)
{
    $output = '';
    $output .= '
        <li class="item">
            <a href="#" class="box-icon w-52"><i class="icon ' . $icon . '"></i></a>
            <div class="content">
                <span class="label">' . $text . ':</span>
                <span>' . $item . '</span>
            </div>
        </li>';
    return $output;
}

/**
 * mi_preloader
 *
 * @return string
 */
function mi_preloader()
{
    $preloader = mi_get_option('mi_preloader');
    $output = '';
    if ($preloader !== 'on') {
        return $output;
    }
    $output .= '
    <!-- preload -->
    <div class="preload preload-container">
        <div class="preload-logo">
            <div class="spinner"></div>
            <span class="icon icon-villa-fill"></span>
        </div>
    </div>
    <!-- /preload -->
    ';
    return $output;
}

/**
 * mi_get_icon
 *
 * @param  string $name
 * @return string
 */
function mi_get_icon($name)
{
    $icon = empty($name) || is_null($name) ? null : file_get_contents(MI_DIR . '/assets/icons/' . $name . '.svg');
    return !$icon ? null : $icon;
}

/**
 * mi_dismissible_alert
 *
 * @param  string $message
 * @param  string $type
 * @return string
 */
function mi_dismissible_alert($message, $type = 'success')
{
    $output = '';
    if ($message) {
        $output .= '
        <div class="alert alert-' . $type . ' alert-dismissible d-flex align-items-center gap-2 fade show" role="alert">
        <i class="bi bi-exclamation-triangle-fill"></i>
        <div>' . $message . '</div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        ';
    }
    return $output;
}

/**
 * mi_dashboard_footer
 *
 * @return string
 */
function mi_dashboard_footer()
{
    $site_name = get_bloginfo('name');
    $output = '';
    $output .= '
    <div class="footer-dashboard">
        <p>Copyright © ' . date('Y') . ' ' . $site_name . '</p>
    </div>';
    return $output;
}

/**
 * mi_button_toggle_dashboard_sidebar
 *
 * @return string
 */
function mi_button_toggle_dashboard_sidebar()
{
    $output = '';
    $output .= '
    <div class="button-show-hide show-mb">
            <span class="icon icon-categories fs-3 fw-normal"></span>
        </div>';
    return $output;
}

/**
 * mi_invalid_feedback
 *
 * @return string
 */
function mi_invalid_feedback()
{
    $output = '';
    $output .= '
    <div class="invalid-feedback">' . __('Campo obrigatório', 'mi') . '</div>';
    return $output;
}

/**
 * mi_edit_imovel_progress_bar
 *
 * @param  int $curr_step
 * @return string
 */
function mi_edit_imovel_progress_bar($curr_step = 1)
{
    $steps = [
        1 => __('1. Dados básicos', 'mi'),
        2 => __('2. Detalhes', 'mi'),
        3 => __('3. Fotos', 'mi')
    ];
    $output = '';
    $output .= '
    <ul class="edit-imovel-progress-bar">';
    foreach ($steps as $k => $step) {
        $active = $k === $curr_step ? 'active' : '';
        $output .= '<li class="step ' . $active . '">' . $step . '</li>';
    }
    $output .= '</ul>';
    return $output;
}
