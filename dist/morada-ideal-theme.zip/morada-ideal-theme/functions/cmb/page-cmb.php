<?php
add_action('cmb2_admin_init', 'mi_register_page_metabox');

function mi_register_page_metabox()
{
    $cmb = new_cmb2_box(array(
        'id'            => 'mi_page_metabox',
        'title'         => esc_html__('Opções de página', 'mi'),
        'object_types'  => array('page'), // Post type
        'show_on_cb' => 'mi_show_login_cmb_options',
        'context'    => 'normal',
    ));

    $cmb->add_field(array(
        'name'       => esc_html__('Imagem lateral da página', 'mi'),
        'id'         => 'mi_side_image',
        'desc'       => esc_html__('A imagem é exibida do lado do formulário da página.', 'mi'),
        'type'       => 'file',
        'attributes' => array(
            'accept' => '.jpg,.jpeg,.png'
        )
    ));
}
