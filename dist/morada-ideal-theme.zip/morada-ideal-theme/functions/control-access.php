<?php

add_action('header_dashboard', function () {
    echo mi_control_dashboard_access();
});

/**
 * mi_control_dashboard_access
 *
 * @return string
 */
function mi_control_dashboard_access()
{
    $login_page_id = mi_get_page_id('login');
    if (!is_user_logged_in() && $login_page_id) {
        $post_id = get_the_ID();
        $curr_page_url = get_permalink();
        $_SESSION['mi_login_error_message'] = __('É preciso estar logado para acessar esta área.', 'mi');
        $login_page_url = mi_get_page_url('login');
        $output = '';
        $output .= '
        <script>
        window.location = "' . $login_page_url . '?redirect_to=' . urlencode($curr_page_url) . '";
        </script>
        ';
        return $output;
    }
}
